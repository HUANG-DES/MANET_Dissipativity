"""
事件定义：BR, FR, RQ, RR, RT, LD, TO, SO, RE, SS, SC, CS, EW, AC
"""

from enum import Enum


class Event(Enum):
    """DES 中的事件"""
    BR = "Broadcast_RREQ"       # 广播 RREQ
    FR = "Forward_RREQ"         # 转发 RREQ
    RQ = "Receive_RREQ"         # 接收以自己为目的地的 RREQ
    RR = "Receive_RREP"         # 接收 RREP
    RT = "Route_Timeout"        # 路由超时
    LD = "Link_Down"            # 链路断开
    TO = "Timeout"              # 超时
    SO = "Suboptimal"           # 非最优路径
    RE = "Reset"                # 重置
    # ISAC 新增事件
    SS = "Start_Sense"          # 启动感知
    SC = "Sense_Completed"      # 感知完成
    CS = "Close_Sense"          # 关闭感知
    EW = "Early_Warning"        # 预警
    AC = "Adjustment_Completed" # 调整完成


# AODV-MANET 的事件集合
AODV_EVENTS = {Event.BR, Event.FR, Event.RQ, Event.RR,
               Event.RT, Event.LD, Event.TO, Event.SO, Event.RE}

# ISAC-MANET 的事件集合
ISAC_EVENTS = AODV_EVENTS | {Event.SS, Event.SC, Event.CS,
                              Event.EW, Event.AC}

# 可控事件集合
CONTROLLABLE_EVENTS = {Event.BR, Event.FR, Event.SS, Event.CS,
                       Event.RE, Event.AC}


if __name__ == "__main__":
    print("AODV 事件数:", len(AODV_EVENTS))
    print("ISAC 事件数:", len(ISAC_EVENTS))
    print("可控事件:", [e.name for e in CONTROLLABLE_EVENTS])