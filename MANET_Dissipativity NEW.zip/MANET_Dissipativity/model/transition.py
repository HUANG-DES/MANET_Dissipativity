"""
转移函数 δ(q, e)
"""

from model.state import State
from model.events import Event


# 单节点转移表：{当前状态: {事件: 下一状态}}
# 参考论文 Table III
TRANSITIONS = {
    State.I: {
        Event.SS: State.S,
        Event.BR: State.W,
        Event.FR: State.W,
        Event.RQ: State.A,
    },
    State.S: {
        Event.SC: State.I,
        Event.CS: State.I,
    },
    State.W: {
        Event.TO: State.I,
        Event.SO: State.I,
        Event.RR: State.A,
    },
    State.A: {
        Event.SS: State.S,
        Event.EW: State.M,
        Event.RT: State.I,
        Event.LD: State.E,
    },
    State.M: {
        Event.AC: State.A,
    },
    State.E: {
        Event.RE: State.I,
    },
}


def delta(state: State, event: Event):
    """
    单节点转移函数。

    返回:
        下一状态，若未定义则返回 None
    """
    return TRANSITIONS.get(state, {}).get(event, None)


def delta_global(global_state: tuple, node_idx: int, event: Event):
    """
    全局转移函数：只改变 node_idx 对应节点的状态，其余节点保持。

    参数:
        global_state: 全局状态元组，如 (State.I, State.W, ...)
        node_idx: 触发事件的节点索引
        event: 事件

    返回:
        新的全局状态元组，若转移未定义则返回 None
    """
    current = global_state[node_idx]
    next_state = delta(current, event)
    if next_state is None:
        return None
    new_state = list(global_state)
    new_state[node_idx] = next_state
    return tuple(new_state)


if __name__ == "__main__":
    # 快速检查
    print("I --SS-->", delta(State.I, Event.SS))
    print("A --EW-->", delta(State.A, Event.EW))
    print("M --AC-->", delta(State.M, Event.AC))
    print("E --RE-->", delta(State.E, Event.RE))
    print("I --RR-->", delta(State.I, Event.RR))  # 应为 None

    g = (State.I, State.W, State.A)
    print("全局转移 (I,W,A) node0 --BR-->", delta_global(g, 0, Event.BR))