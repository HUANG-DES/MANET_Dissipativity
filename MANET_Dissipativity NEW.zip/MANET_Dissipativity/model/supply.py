"""
供给率函数 ω(e, q)
"""

import math
from model.state import State
from model.events import Event


# ---------- 默认参数 ----------
# 功耗参数（单位：mW）
P_TX_OMNI = 100.0     # 全向发射功耗
P_TX_DIR = 50.0       # 定向发射功耗
P_RX = 80.0           # 接收功耗
P_SENSE = 30.0        # 感知功耗
P_ADJUST = 40.0       # 调整功耗

# 开销参数
C_BROADCAST = 10.0    # 单次广播开销
C_DIRECTED = 2.0      # 定向发送开销
C_SENSING = 3.0       # 感知处理开销
C_PROCESS = 20.0      # 内部处理开销
C_CONTROL = 5.0       # 预警控制开销

# 邻居数
N_NEIGHBORS = 3


def omega(event: Event, state: State, isac: bool = True):
    """
    单节点供给率 ω(e, q)。

    参数:
        event: 事件
        state: 触发事件时的当前状态
        isac: True 表示 ISAC-MANET，False 表示 AODV-MANET

    返回:
        供给率值
    """
    if isac:
        # ---------- ISAC-MANET ----------
        if event in (Event.BR,):
            return P_TX_DIR + C_DIRECTED + C_SENSING
        elif event == Event.FR:
            return P_TX_DIR + C_DIRECTED
        elif event in (Event.RQ, Event.RR):
            return P_RX + C_PROCESS
        elif event == Event.SS:
            return P_SENSE
        elif event in (Event.SC, Event.CS):
            return 0.0
        elif event == Event.EW:
            return C_CONTROL
        elif event == Event.AC:
            return P_ADJUST
        elif event in (Event.TO, Event.SO):
            return C_PROCESS
        elif event in (Event.LD, Event.RT, Event.RE):
            return 0.0
        else:
            raise ValueError(f"Unknown event: {event}")
    else:
        # ---------- AODV-MANET ----------
        if event in (Event.BR, Event.FR):
            return P_TX_OMNI + C_BROADCAST * N_NEIGHBORS
        elif event in (Event.RQ, Event.RR):
            return P_RX + C_PROCESS
        elif event in (Event.TO, Event.SO):
            return C_PROCESS
        elif event in (Event.LD, Event.RT, Event.RE):
            return 0.0
        else:
            raise ValueError(f"Unknown event: {event}")


def supply_rate_single_hop(event: Event, isac: bool = True):
    """
    无效广播的单次耗散量。
    """
    if isac:
        return P_TX_DIR + C_DIRECTED + C_SENSING
    else:
        return P_TX_OMNI + N_NEIGHBORS * (P_RX + C_PROCESS)


if __name__ == "__main__":
    print("--- AODV-MANET ---")
    print("ω(BR, I) =", omega(Event.BR, State.I, isac=False))
    print("ω(RR, W) =", omega(Event.RR, State.W, isac=False))
    print("ω(LD, A) =", omega(Event.LD, State.A, isac=False))

    print("\n--- ISAC-MANET ---")
    print("ω(BR, I) =", omega(Event.BR, State.I, isac=True))
    print("ω(SS, I) =", omega(Event.SS, State.I, isac=True))
    print("ω(EW, A) =", omega(Event.EW, State.A, isac=True))
    print("ω(AC, M) =", omega(Event.AC, State.M, isac=True))