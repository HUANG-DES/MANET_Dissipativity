"""
状态定义：I, W, A, E, S, M
"""

from enum import Enum


class State(Enum):
    """单节点的六个状态"""
    I = "Idle"        # 空闲
    W = "Wait"        # 等待路由回复
    A = "Active"      # 路由活跃
    E = "Error"       # 错误
    S = "Sensing"     # ISAC 感知
    M = "Adjusting"   # 调整


# AODV-MANET 的状态集合
AODV_STATES = {State.I, State.W, State.A, State.E}

# ISAC-MANET 的状态集合
ISAC_STATES = {State.I, State.W, State.A, State.E, State.S, State.M}


# 固定顺序，与论文一致
ISAC_ORDER = [State.I, State.W, State.A, State.E, State.S, State.M]
AODV_ORDER = [State.I, State.W, State.A, State.E]


def state_space(num_nodes: int, isac: bool = True):
    """
    生成 num_nodes 个节点的全局状态空间。

    参数:
        num_nodes: 节点数
        isac: True 表示 ISAC-MANET（6 状态），False 表示 AODV-MANET（4 状态）

    返回:
        全局状态元组的列表
    """
    from itertools import product
    order = ISAC_ORDER if isac else AODV_ORDER
    return list(product(order, repeat=num_nodes))


if __name__ == "__main__":
    # 快速检查
    print("AODV 单节点状态顺序:", [s.name for s in AODV_ORDER])
    print("ISAC 单节点状态顺序:", [s.name for s in ISAC_ORDER])
    print("七节点 AODV 理论状态数:", len(state_space(7, isac=False)))
    print("七节点 ISAC 理论状态数:", len(state_space(7, isac=True)))
    print("前 3 个 ISAC 全局状态:")
    for g in state_space(7, isac=True)[:3]:
        print("  ", tuple(s.name for s in g))