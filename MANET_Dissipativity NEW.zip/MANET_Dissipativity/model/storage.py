"""
存储函数 V(q)
"""

import math
from model.state import State


# ---------- 默认参数 ----------
# 权重系数（可调）
ALPHA = 0.5   # W 状态的权重
BETA = 0.8    # A 状态的权重
GAMMA = 0.3   # S 状态中距离项的权重
EPSILON = 0.2 # S 状态中邻居熵项的权重
ZETA = 0.4    # M 状态的权重

# W 状态的指数退避参数
LAMBDA = 0.1

# 其他常量
N_ROUTE = 1          # 有效路由条目数
D_TARGET_INV = 0.5   # d_target^{-1}
I_NEIGHBOR = 0.6     # 邻居信息熵
I_WARNING = 0.7      # 预警信息价值


def V(state: State, t_wait: float = 10.0):
    """
    单节点存储函数 V(q)。

    参数:
        state: 节点状态
        t_wait: 在 W 状态的等待时间

    返回:
        存储函数值
    """
    if state == State.I:
        return 0.0
    elif state == State.E:
        return 0.0
    elif state == State.W:
        return ALPHA * (1 - math.exp(-LAMBDA * t_wait))
    elif state == State.A:
        return BETA * N_ROUTE
    elif state == State.S:
        return V(State.A) + GAMMA * D_TARGET_INV + EPSILON * I_NEIGHBOR
    elif state == State.M:
        return V(State.A) + ZETA * I_WARNING
    else:
        raise ValueError(f"Unknown state: {state}")


def V_global(global_state: tuple, t_wait: float = 10.0):
    """
    全局存储函数：各节点存储函数之和。
    """
    return sum(V(s, t_wait) for s in global_state)


if __name__ == "__main__":
    for s in [State.I, State.W, State.A, State.E, State.S, State.M]:
        print(f"V({s.name}) = {V(s):.4f}")

    g = (State.I, State.W, State.A, State.A, State.A, State.A, State.A)
    print("全局 V =", V_global(g))