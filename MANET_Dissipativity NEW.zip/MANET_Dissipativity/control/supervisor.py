"""
Algorithm 1: Dissipativity-Enforcing Supervisor Synthesis

基于 Theorem 2 的构造性证明，合成监督控制器 C，使得闭环系统 C/G
在所有状态-事件对上满足耗散不等式。

算法流程：
    Step 1: 识别违反耗散性条件的可控事件对 (q, e)
    Step 2: 构建监督控制器 C(q) = {e ∈ E_c | (q, e) ∉ Q_forbid}
    Step 3: 验证非阻塞性
"""

from collections import defaultdict

from model.state import State
from model.events import Event, CONTROLLABLE_EVENTS
from model.storage import V
from model.supply import omega
from analysis.dissipativity import verify_transition


EPS = 1e-6


def is_controllable(event: Event) -> bool:
    """判断事件是否可控"""
    return event in CONTROLLABLE_EVENTS


def identify_forbidden_pairs(transitions, isac=True, t_wait=10.0, mu=0.01):
    """
    Step 1: 识别违反耗散性条件的可控事件对。

    排除结构性零裕度转移（ω = 0 且 ΔV = 0），
    因为它们满足耗散不等式，只是没有正裕度。
    """
    Q_forbid = set()

    for (current, node_idx, event), next_state in transitions.items():
        if not is_controllable(event):
            continue

        _, w, dv, diff = verify_transition(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )

        # 排除结构性零裕度转移
        if abs(w) < EPS and abs(dv) < EPS:
            continue

        # 条件：ω − ΔV < μ
        if diff < mu - EPS:
            Q_forbid.add((current, node_idx, event))

    return Q_forbid


def build_supervisor(Q_forbid, transitions, isac: bool = True):
    """
    Step 2: 构建监督控制器。

    C(current) = {e ∈ E_c | (current, node_idx, e) ∉ Q_forbid
                  for all node_idx}

    即：在状态 current 下，允许所有未被禁止的可控事件。

    返回:
        supervisor: 字典 {current: set of allowed controllable events}
    """
    # 收集所有可达状态
    all_states = set()
    for (current, node_idx, event) in transitions.keys():
        all_states.add(current)

    supervisor = {}
    for current in all_states:
        allowed = set()
        for event in CONTROLLABLE_EVENTS:
            # 检查该事件在该状态下是否被禁止
            # 由于转移是按 (current, node_idx, event) 索引的，
            # 我们需要检查该状态下是否有任何 node_idx 对应的 (current, node_idx, event) 被禁止
            forbidden = False
            for node_idx in range(len(current)):
                if (current, node_idx, event) in Q_forbid:
                    forbidden = True
                    break
            if not forbidden:
                allowed.add(event)
        supervisor[current] = allowed

    return supervisor


def verify_closed_loop(transitions, supervisor, isac: bool = True,
                        t_wait: float = 10.0, mu: float = 0.01):
    """
    Step 3: 验证闭环系统 C/G 的耗散性和非阻塞性。

    参数:
        transitions: 原始转移关系
        supervisor: 监督控制器
        isac: 是否 ISAC-MANET
        t_wait: W 状态等待时间
        mu: 耗散裕度

    返回:
        result: 字典，包含：
            - dissipative: 闭环系统是否耗散
            - nonblocking: 闭环系统是否非阻塞
            - allowed_transitions: 闭环系统中允许的转移数
            - forbidden_transitions: 被禁止的转移数
            - violations: 违反耗散性的转移列表
    """
    allowed_count = 0
    forbidden_count = 0
    violations = []

    for (current, node_idx, event), next_state in transitions.items():
        # 检查该转移是否被 supervisor 允许
        if is_controllable(event):
            if event not in supervisor.get(current, set()):
                forbidden_count += 1
                continue

        allowed_count += 1

        # 验证耗散性
        _, w, dv, diff = verify_transition(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )

        if diff < -EPS:
            violations.append((current, node_idx, event, next_state,
                               w, dv, diff))

    # 检查非阻塞性：每个可达状态是否至少有一个允许的转移
    all_states = set()
    for (current, _, _) in transitions.keys():
        all_states.add(current)

    nonblocking = True
    blocked_states = []
    for current in all_states:
        has_transition = False
        for (c, node_idx, event), next_state in transitions.items():
            if c == current:
                if is_controllable(event):
                    if event in supervisor.get(current, set()):
                        has_transition = True
                        break
                else:
                    has_transition = True
                    break
        if not has_transition:
            nonblocking = False
            blocked_states.append(current)

    result = {
        "dissipative": len(violations) == 0,
        "nonblocking": nonblocking,
        "allowed_transitions": allowed_count,
        "forbidden_transitions": forbidden_count,
        "violations": violations,
        "blocked_states": blocked_states,
    }

    return result


def synthesize_supervisor(transitions, isac: bool = True,
                           t_wait: float = 10.0, mu: float = 0.01,
                           verbose: bool = True):
    """
    完整的监督控制器合成流程。

    参数:
        transitions: 转移关系字典
        isac: 是否 ISAC-MANET
        t_wait: W 状态等待时间
        mu: 耗散裕度
        verbose: 是否打印中间结果

    返回:
        supervisor: 监督控制器
        result: 验证结果
    """
    if verbose:
        print(f"\n{'='*60}")
        print(f"Algorithm 1: Supervisor Synthesis ({'ISAC' if isac else 'AODV'}-MANET)")
        print(f"{'='*60}")

    # Step 1: 识别禁止对
    if verbose:
        print("\n[Step 1] 识别违反耗散性条件的可控事件对...")

    Q_forbid = identify_forbidden_pairs(transitions, isac=isac,
                                         t_wait=t_wait, mu=mu)

    if verbose:
        print(f"  禁止的可控事件对数量: {len(Q_forbid)}")

        # 按事件类型统计
        from collections import Counter
        event_counter = Counter()
        for (_, _, event) in Q_forbid:
            event_counter[event.name] += 1
        for event_name, count in event_counter.most_common():
            print(f"    {event_name}: {count}")

    # Step 2: 构建监督控制器
    if verbose:
        print("\n[Step 2] 构建监督控制器...")

    supervisor = build_supervisor(Q_forbid, transitions, isac=isac)

    if verbose:
        print(f"  监督控制器覆盖状态数: {len(supervisor)}")
        print(f"  平均每状态允许事件数: "
              f"{sum(len(v) for v in supervisor.values()) / len(supervisor):.2f}")

    # Step 3: 验证闭环系统
    if verbose:
        print("\n[Step 3] 验证闭环系统 C/G...")

    result = verify_closed_loop(transitions, supervisor,
                                 isac=isac, t_wait=t_wait, mu=mu)

    if verbose:
        print(f"  闭环系统耗散性: {'✓ 满足' if result['dissipative'] else '✗ 违反'}")
        print(f"  闭环系统非阻塞性: {'✓ 满足' if result['nonblocking'] else '✗ 违反'}")
        print(f"  允许的转移数: {result['allowed_transitions']}")
        print(f"  禁止的转移数: {result['forbidden_transitions']}")

        if result['violations']:
            print(f"  违反耗散性的转移数: {len(result['violations'])}")
            for i, (current, node_idx, event, next_state, w, dv, diff) in \
                    enumerate(result['violations'][:5]):
                print(f"    [{i+1}] {tuple(s.name for s in current)} "
                      f"--(node{node_idx}, {event.name})--> "
                      f"{tuple(s.name for s in next_state)}")
                print(f"        ω = {w:.4f}, ΔV = {dv:.4f}, ω − ΔV = {diff:.4f}")

    return supervisor, result


def compare_supervisor_effect(trans_aodv, trans_isac,
                               t_wait: float = 10.0, mu: float = 0.01):
    """
    对比 AODV-MANET 和 ISAC-MANET 的监督控制器效果。
    """
    print("\n" + "=" * 70)
    print("AODV-MANET vs ISAC-MANET 监督控制器对比")
    print("=" * 70)

    sup_aodv, result_aodv = synthesize_supervisor(
        trans_aodv, isac=False, t_wait=t_wait, mu=mu, verbose=False
    )
    sup_isac, result_isac = synthesize_supervisor(
        trans_isac, isac=True, t_wait=t_wait, mu=mu, verbose=False
    )

    print(f"\n{'指标':<30}{'AODV-MANET':<20}{'ISAC-MANET':<20}")
    print("-" * 70)
    print(f"{'闭环耗散性':<30}"
          f"{'✓' if result_aodv['dissipative'] else '✗':<20}"
          f"{'✓' if result_isac['dissipative'] else '✗':<20}")
    print(f"{'闭环非阻塞性':<30}"
          f"{'✓' if result_aodv['nonblocking'] else '✗':<20}"
          f"{'✓' if result_isac['nonblocking'] else '✗':<20}")
    print(f"{'允许转移数':<30}"
          f"{result_aodv['allowed_transitions']:<20}"
          f"{result_isac['allowed_transitions']:<20}")
    print(f"{'禁止转移数':<30}"
          f"{result_aodv['forbidden_transitions']:<20}"
          f"{result_isac['forbidden_transitions']:<20}")
    print(f"{'违反耗散性转移数':<30}"
          f"{len(result_aodv['violations']):<20}"
          f"{len(result_isac['violations']):<20}")

    return sup_aodv, sup_isac, result_aodv, result_isac


if __name__ == "__main__":
    from analysis.reachability import reachable_states

    print(">>> 开始可达性遍历...")
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)

    print(f"AODV 可达状态: {len(visited_aodv)}, 转移数: {len(trans_aodv)}")
    print(f"ISAC 可达状态: {len(visited_isac)}, 转移数: {len(trans_isac)}")

    # 单独合成 ISAC-MANET 的监督控制器（详细输出）
    sup_isac, result_isac = synthesize_supervisor(
        trans_isac, isac=True, t_wait=10.0, mu=0.01, verbose=True
    )

    # 对比 AODV 和 ISAC
    compare_supervisor_effect(trans_aodv, trans_isac, t_wait=10.0, mu=0.01)