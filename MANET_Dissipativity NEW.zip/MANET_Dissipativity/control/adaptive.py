"""
Algorithm 2: Adaptive Dissipativity-Enforcing Supervisor

仅适用于 ISAC-MANET（AODV-MANET 无感知能力，不存在感知频率）。

在 Algorithm 1 的基础上，引入感知频率 f 的自适应调整，
使得闭环系统在满足耗散性约束的同时最大化耗散效率。

采用感知价值边际递减模型：
    V_total(f) = V_data + α · (1 − e^{−λf})
    ω_total(f) = ω_data + f · β

这样 η(f) 存在内部极值点，f* 可通过数值搜索求解。
"""

import math

from model.supply import P_SENSE, P_ADJUST
from analysis.dissipativity import verify_transition
from control.supervisor import synthesize_supervisor


EPS = 1e-6

# ---------- 默认参数 ----------
ALPHA_SENSE = 1.0      # ΔV_sense · t_sense，单次感知带来的存储价值增量
T_SENSE = 1.0          # 单次感知持续时间
T_ADJ = 1.0            # 单次调整持续时间
LAMBDA_SENSE = 1.0     # 感知价值增长速率（边际递减）
DEFAULT_MU = 0.01      # 初始耗散裕度
EFFICIENCY_THRESHOLD = 0.05  # 效率偏离阈值


def compute_alpha():
    """α = ΔV_sense · t_sense"""
    return ALPHA_SENSE * T_SENSE


def compute_beta():
    """β = P_sense · t_sense + P_adjust · t_adj"""
    return P_SENSE * T_SENSE + P_ADJUST * T_ADJ


def compute_baseline(transitions, isac=True, t_wait=10.0):
    """
    预先计算 V_data 和 ω_data（所有可达转移的平均值）。

    只遍历一次转移，避免在绘制 η(f) 曲线时重复计算。

    返回:
        (v_data, w_data)
    """
    total_w = 0.0
    total_dv = 0.0
    count = 0

    for (current, node_idx, event), next_state in transitions.items():
        _, w, dv, _ = verify_transition(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )
        total_w += w
        total_dv += dv
        count += 1

    if count == 0:
        return EPS, EPS

    return max(total_dv / count, EPS), max(total_w / count, EPS)


def compute_efficiency_at_frequency(f, v_data, w_data):
    """
    用预计算的基线计算 η(f)。

    参数:
        f: 感知频率
        v_data: 数据传输带来的存储价值基线
        w_data: 数据传输带来的能量消耗基线

    返回:
        η(f) = V_total(f) / ω_total(f)
    """
    alpha = compute_alpha()
    beta = compute_beta()

    v_total = v_data + alpha * (1 - math.exp(-LAMBDA_SENSE * f))
    w_total = w_data + f * beta

    if w_total < EPS:
        return 0.0

    return v_total / w_total


def optimal_frequency(v_data, w_data, f_min=0.1, f_max=2.0, num_points=2000):
    """
    计算最优感知频率 f*（数值搜索 η(f) 的最大值）。

    参数:
        v_data, w_data: 基线
        f_min, f_max: 搜索范围
        num_points: 搜索点数

    返回:
        最优频率 f*
    """
    best_f = f_min
    best_eta = -float("inf")

    for i in range(num_points):
        f = f_min + (f_max - f_min) * i / (num_points - 1)
        eta = compute_efficiency_at_frequency(f, v_data, w_data)
        if eta > best_eta:
            best_eta = eta
            best_f = f

    return best_f


def synthesize_adaptive_supervisor(transitions, isac=True,
                                    t_wait=10.0,
                                    mu_0=DEFAULT_MU,
                                    threshold=EFFICIENCY_THRESHOLD,
                                    max_iter=20,
                                    verbose=True):
    """
    Algorithm 2: 自适应耗散性监督控制器（仅 ISAC-MANET）。

    参数:
        transitions: 转移关系字典
        isac: 必须为 True（AODV-MANET 不适用）
        t_wait: W 状态等待时间
        mu_0: 初始耗散裕度
        threshold: 效率偏离阈值
        max_iter: 最大迭代次数
        verbose: 是否打印中间结果

    返回:
        result: 字典，包含频率历史、效率历史、最终控制器等
    """
    if not isac:
        raise ValueError("Algorithm 2 仅适用于 ISAC-MANET（AODV-MANET 无感知能力）。")

    if verbose:
        print(f"\n{'='*60}")
        print(f"Algorithm 2: Adaptive Supervisor (ISAC-MANET)")
        print(f"{'='*60}")

    # Step 0: 预计算基线
    v_data, w_data = compute_baseline(transitions, isac=isac, t_wait=t_wait)

    # Step 1: 计算最优参数
    alpha = compute_alpha()
    beta = compute_beta()
    f_star = optimal_frequency(v_data, w_data)

    if verbose:
        print(f"\n[Step 0] 预计算基线")
        print(f"  V_data = {v_data:.6f}")
        print(f"  ω_data = {w_data:.6f}")
        print(f"\n[Step 1] 计算最优参数")
        print(f"  α = ΔV_sense · t_sense = {alpha:.4f}")
        print(f"  β = P_sense · t_sense + P_adjust · t_adj = {beta:.4f}")
        print(f"  λ = {LAMBDA_SENSE:.4f}（感知价值增长速率）")
        print(f"  f* (数值搜索) = {f_star:.4f}")
        print(f"  η(f*) = "
              f"{compute_efficiency_at_frequency(f_star, v_data, w_data):.4f}")

    # Step 2: 初始监督控制器
    if verbose:
        print(f"\n[Step 2] 初始监督控制器合成（μ = {mu_0}）")

    supervisor, synth_result = synthesize_supervisor(
        transitions, isac=isac, t_wait=t_wait,
        mu=mu_0, verbose=False
    )

    if verbose:
        print(f"  禁止转移数: {synth_result['forbidden_transitions']}")
        print(f"  闭环耗散性: {'✓' if synth_result['dissipative'] else '✗'}")

    # Step 3: 自适应调整
    if verbose:
        print(f"\n[Step 3] 自适应调整")

    f_current = f_star * 0.5
    mu_current = mu_0
    f_history = [f_current]
    eta_history = []

    converged = False
    eta_optimal = compute_efficiency_at_frequency(f_star, v_data, w_data)

    for iteration in range(max_iter):
        eta_current = compute_efficiency_at_frequency(
            f_current, v_data, w_data
        )
        eta_history.append(eta_current)

        if verbose:
            print(f"  迭代 {iteration+1}: f = {f_current:.4f}, "
                  f"η = {eta_current:.6f}, μ = {mu_current:.4f}")

        deviation = abs(eta_current - eta_optimal) / max(eta_optimal, EPS)

        if deviation < threshold:
            converged = True
            if verbose:
                print(f"  → 收敛（偏离 {deviation*100:.2f}% "
                      f"< {threshold*100:.0f}%）")
            break

        f_current = f_current + 0.5 * (f_star - f_current)
        f_history.append(f_current)

        _, result = synthesize_supervisor(
            transitions, isac=isac, t_wait=t_wait,
            mu=mu_current, verbose=False
        )

        if not result['dissipative']:
            mu_current *= 1.5
            if verbose:
                print(f"  → 耗散性约束被违反，μ 增大到 {mu_current:.4f}")

    supervisor, final_result = synthesize_supervisor(
        transitions, isac=isac, t_wait=t_wait,
        mu=mu_current, verbose=False
    )

    result = {
        "f_optimal": f_star,
        "f_history": f_history,
        "eta_history": eta_history,
        "mu_final": mu_current,
        "supervisor": supervisor,
        "converged": converged,
        "final_result": final_result,
        "v_data": v_data,
        "w_data": w_data,
    }

    if verbose:
        print(f"\n[最终结果]")
        print(f"  最优频率 f* = {f_star:.4f}")
        print(f"  最终频率 f = {f_current:.4f}")
        print(f"  最终耗散裕度 μ = {mu_current:.4f}")
        print(f"  是否收敛: {'✓' if converged else '✗'}")
        print(f"  禁止转移数: {final_result['forbidden_transitions']}")

    return result


def plot_frequency_efficiency(v_data, w_data, f_range=None, num_points=100):
    """
    计算感知频率 f 与耗散效率 η(f) 的关系曲线。

    参数:
        v_data, w_data: 基线
        f_range: 搜索范围 (f_min, f_max)
        num_points: 搜索点数

    返回:
        (f_values, eta_values)
    """
    if f_range is None:
        f_star = optimal_frequency(v_data, w_data, num_points=200)
        f_range = (0.1, max(f_star * 3, 0.5))

    f_values = [f_range[0] + (f_range[1] - f_range[0]) * i / (num_points - 1)
                for i in range(num_points)]
    eta_values = [compute_efficiency_at_frequency(f, v_data, w_data)
                  for f in f_values]

    return f_values, eta_values


def compare_isac_with_aodv_baseline(trans_aodv, trans_isac,
                                     t_wait=10.0, mu_0=DEFAULT_MU):
    """
    ISAC-MANET 自适应监督控制器 vs AODV-MANET 基准对比。

    AODV-MANET 没有感知能力，不参与频率优化，仅作为基准。
    """
    print("\n" + "=" * 70)
    print("ISAC-MANET 自适应监督控制器 vs AODV-MANET 基准对比")
    print("=" * 70)

    # AODV-MANET：仅计算基准效率
    print("\n--- AODV-MANET（基准，无感知能力）---")
    v_aodv, w_aodv = compute_baseline(trans_aodv, isac=False, t_wait=t_wait)
    eta_aodv = v_aodv / w_aodv if w_aodv > EPS else 0.0
    print(f"  V_data = {v_aodv:.6f}")
    print(f"  ω_data = {w_aodv:.6f}")
    print(f"  平均耗散效率 η = {eta_aodv:.6f}")

    # ISAC-MANET：自适应监督控制器
    print("\n--- ISAC-MANET（自适应监督控制器）---")
    result_isac = synthesize_adaptive_supervisor(
        trans_isac, isac=True, t_wait=t_wait, mu_0=mu_0, verbose=True
    )

    # 计算 ISAC-MANET 在最优频率下的效率
    eta_isac = compute_efficiency_at_frequency(
        result_isac["f_optimal"],
        result_isac["v_data"],
        result_isac["w_data"]
    )

    print("\n" + "=" * 70)
    print("对比总结")
    print("=" * 70)
    print(f"{'指标':<25}{'AODV-MANET':<18}{'ISAC-MANET':<18}")
    print("-" * 70)
    print(f"{'平均耗散效率 η':<25}"
          f"{eta_aodv:<18.6f}"
          f"{eta_isac:<18.6f}")
    print(f"{'效率提升倍数':<25}"
          f"{'基准':<18}"
          f"{eta_isac / eta_aodv:<18.2f}")
    print(f"{'最优频率 f*':<25}"
          f"{'N/A':<18}"
          f"{result_isac['f_optimal']:<18.4f}")
    print(f"{'是否收敛':<25}"
          f"{'N/A':<18}"
          f"{'✓' if result_isac['converged'] else '✗':<18}")
    print(f"{'最终 μ':<25}"
          f"{'N/A':<18}"
          f"{result_isac['mu_final']:<18.4f}")
    print(f"{'禁止转移数':<25}"
          f"{'N/A':<18}"
          f"{result_isac['final_result']['forbidden_transitions']:<18}")

    return result_isac


if __name__ == "__main__":
    from analysis.reachability import reachable_states

    print(">>> 开始可达性遍历...")
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)

    print(f"AODV 可达状态: {len(visited_aodv)}, 转移数: {len(trans_aodv)}")
    print(f"ISAC 可达状态: {len(visited_isac)}, 转移数: {len(trans_isac)}")

    # 只对 ISAC-MANET 做一次自适应监督控制
    result_isac = synthesize_adaptive_supervisor(
        trans_isac, isac=True, t_wait=10.0, verbose=True
    )

    # 频率-效率曲线
    print("\n>>> 计算频率-效率曲线...")
    f_values, eta_values = plot_frequency_efficiency(
        result_isac["v_data"], result_isac["w_data"], num_points=50
    )
    max_eta = max(eta_values)
    max_idx = eta_values.index(max_eta)
    print(f"  曲线最大值: f = {f_values[max_idx]:.4f}, η = {max_eta:.6f}")
    print(f"  Algorithm 2 给出的 f* = {result_isac['f_optimal']:.4f}")

    # AODV-MANET 基准
    v_aodv, w_aodv = compute_baseline(trans_aodv, isac=False, t_wait=10.0)
    eta_aodv = v_aodv / w_aodv if w_aodv > EPS else 0.0

    # ISAC-MANET 在无控制情况下的效率（直接使用基线）
    eta_isac_uncontrolled = (result_isac["v_data"] /
                              result_isac["w_data"]) if result_isac["w_data"] > EPS else 0.0

    # ISAC-MANET 在最优频率下的效率
    eta_isac_optimal = compute_efficiency_at_frequency(
        result_isac["f_optimal"],
        result_isac["v_data"],
        result_isac["w_data"]
    )

    print("\n" + "=" * 70)
    print("AODV-MANET vs ISAC-MANET 耗散效率对比")
    print("=" * 70)
    print(f"{'指标':<30}{'η':<15}")
    print("-" * 70)
    print(f"{'AODV-MANET（基准）':<30}{eta_aodv:<15.6f}")
    print(f"{'ISAC-MANET（无控制）':<30}{eta_isac_uncontrolled:<15.6f}")
    print(f"{'ISAC-MANET（有supervisor，f*={:.4f}）'.format(result_isac['f_optimal']):<30}"
          f"{eta_isac_optimal:<15.6f}")