"""
experiment/run_case_study.py

整合所有分析，生成七节点 ISAC-MANET 的完整案例研究报告：
    1. 可达状态统计
    2. 耗散性验证（Theorem 1）
    3. 三阶段耗散效率对比
    4. 监督控制器合成（Algorithm 1）
    5. 自适应监督控制器（Algorithm 2）
    6. 频率-效率曲线
    7. 表 9 数值生成
"""

import time
import sys
import os

# 添加项目根目录到 sys.path，方便导入
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analysis.reachability import reachable_states
from analysis.dissipativity import (
    verify_all_transitions, print_summary, dissipativity_margin
)
from analysis.efficiency import compare_efficiency_aodv_isac
from control.supervisor import compare_supervisor_effect
from control.adaptive import (
    synthesize_adaptive_supervisor,
    compute_baseline,
    compute_efficiency_at_frequency,
    plot_frequency_efficiency,
)


def print_section(title):
    """打印分节标题"""
    print("\n")
    print("=" * 78)
    print(f"  {title}")
    print("=" * 78)


def run_case_study():
    """运行完整的案例研究"""

    total_start = time.time()

    # ============================================================
    # 1. 可达状态遍历
    # ============================================================
    print_section("1. 可达状态遍历")

    t0 = time.time()
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)
    t1 = time.time()

    print(f"AODV-MANET 可达状态数: {len(visited_aodv)}")
    print(f"AODV-MANET 转移数:     {len(trans_aodv)}")
    print(f"ISAC-MANET 可达状态数: {len(visited_isac)}")
    print(f"ISAC-MANET 转移数:     {len(trans_isac)}")
    print(f"遍历耗时: {t1 - t0:.2f} 秒")

    # ============================================================
    # 2. 耗散性验证（Theorem 1）
    # ============================================================
    print_section("2. 耗散性验证（Theorem 1）")

    t0 = time.time()
    _, summary_aodv = verify_all_transitions(
        visited_aodv, trans_aodv, isac=False
    )
    _, summary_isac = verify_all_transitions(
        visited_isac, trans_isac, isac=True
    )
    t1 = time.time()

    print_summary(summary_aodv, "AODV-MANET")
    print()
    print_summary(summary_isac, "ISAC-MANET")
    print(f"\n验证耗时: {t1 - t0:.2f} 秒")

    # 耗散裕度
    mu_aodv, _ = dissipativity_margin(trans_aodv, isac=False, strict=True)
    mu_isac, _ = dissipativity_margin(trans_isac, isac=True, strict=True)

    print(f"\n耗散裕度（排除结构性零裕度转移）:")
    print(f"  AODV-MANET: μ = {mu_aodv:.4f}")
    print(f"  ISAC-MANET: μ = {mu_isac:.4f}")

    # ============================================================
    # 3. 三阶段耗散效率对比
    # ============================================================
    print_section("3. 三阶段耗散效率对比")

    t0 = time.time()
    compare_efficiency_aodv_isac(
        visited_aodv, trans_aodv,
        visited_isac, trans_isac
    )
    t1 = time.time()
    print(f"\n耗时: {t1 - t0:.2f} 秒")

    # ============================================================
    # 4. 监督控制器合成（Algorithm 1）
    # ============================================================
    print_section("4. 监督控制器合成（Algorithm 1）")

    t0 = time.time()
    compare_supervisor_effect(
        trans_aodv, trans_isac,
        t_wait=10.0, mu=0.01
    )
    t1 = time.time()
    print(f"\n耗时: {t1 - t0:.2f} 秒")

    # ============================================================
    # 5. 自适应监督控制器（Algorithm 2）
    # ============================================================
    print_section("5. 自适应监督控制器（Algorithm 2，仅 ISAC-MANET）")

    t0 = time.time()
    result_isac = synthesize_adaptive_supervisor(
        trans_isac, isac=True, t_wait=10.0, verbose=True
    )
    t1 = time.time()
    print(f"\n耗时: {t1 - t0:.2f} 秒")

    # ============================================================
    # 6. 频率-效率曲线
    # ============================================================
    print_section("6. 频率-效率曲线")

    t0 = time.time()
    f_values, eta_values = plot_frequency_efficiency(
        result_isac["v_data"],
        result_isac["w_data"],
        num_points=50
    )
    t1 = time.time()

    max_eta = max(eta_values)
    max_idx = eta_values.index(max_eta)

    print(f"曲线最大值: f = {f_values[max_idx]:.4f}, η = {max_eta:.6f}")
    print(f"Algorithm 2 给出的 f* = {result_isac['f_optimal']:.4f}")
    print(f"两者误差: "
          f"{abs(f_values[max_idx] - result_isac['f_optimal']) / result_isac['f_optimal'] * 100:.2f}%")
    print(f"耗时: {t1 - t0:.2f} 秒")

    # ============================================================
    # 7. 表 9 数值生成
    # ============================================================
    print_section("7. 表 9 数值生成")

    # AODV-MANET 基准效率
    v_aodv, w_aodv = compute_baseline(trans_aodv, isac=False, t_wait=10.0)
    eta_aodv = v_aodv / w_aodv if w_aodv > 1e-9 else 0.0

    # ISAC-MANET 无控制效率（f = 0，不感知）
    eta_isac_no_control = (result_isac["v_data"] /
                            result_isac["w_data"]
                            if result_isac["w_data"] > 1e-9 else 0.0)

    # ISAC-MANET 有 supervisor 效率（f = f*）
    eta_isac_supervised = compute_efficiency_at_frequency(
        result_isac["f_optimal"],
        result_isac["v_data"],
        result_isac["w_data"]
    )

    print(f"\n表 9 数值:")
    print(f"{'指标':<40}{'数值':<15}")
    print("-" * 55)
    print(f"{'AODV-MANET 平均耗散效率':<40}{eta_aodv:<15.6f}")
    print(f"{'ISAC-MANET（无控制）平均耗散效率':<40}{eta_isac_no_control:<15.6f}")
    print(f"{'ISAC-MANET（有supervisor）平均耗散效率':<40}{eta_isac_supervised:<15.6f}")
    print(f"{'ISAC-MANET 最优感知频率 f*':<40}{result_isac['f_optimal']:<15.4f}")
    print(f"{'效率提升倍数（vs AODV）':<40}"
          f"{eta_isac_supervised / eta_aodv:<15.2f}")

    # ============================================================
    # 总结
    # ============================================================
    total_end = time.time()

    print_section("案例研究总结")
    print(f"总耗时: {total_end - total_start:.2f} 秒")
    print()
    print("核心结论:")
    print(f"  1. 耗散性验证: AODV-MANET 和 ISAC-MANET 均满足耗散不等式")
    print(f"  2. 耗散裕度: AODV μ = {mu_aodv:.4f}, ISAC μ = {mu_isac:.4f}")
    print(f"  3. 效率对比: ISAC 有 supervisor ({eta_isac_supervised:.6f}) "
          f"vs AODV ({eta_aodv:.6f})")
    print(f"  4. 效率提升: {eta_isac_supervised / eta_aodv:.2f} 倍")
    print(f"  5. 最优频率: f* = {result_isac['f_optimal']:.4f}")
    print(f"  6. 监督控制器: 当前参数下禁止 0 个转移，保持最大行为自由度")


if __name__ == "__main__":
    run_case_study()