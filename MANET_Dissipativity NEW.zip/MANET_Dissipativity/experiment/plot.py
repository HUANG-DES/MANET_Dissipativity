"""
experiment/plot.py

生成四张论文用图：
    Fig. A: 耗散效率对比柱状图（AODV vs ISAC 无控制 vs ISAC 有supervisor）
    Fig. B: 频率-效率曲线（η(f) 随 f 的变化，标注 f*）
    Fig. C: 三阶段耗散效率对比（路由发现/保持/恢复）
    Fig. D: 状态空间对比（可达状态数与转移数）

输出目录：results/figures/
"""

import os
import sys
import time

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams

# 添加项目根目录到 sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analysis.reachability import reachable_states
from analysis.efficiency import aggregate_by_phase
from control.adaptive import (
    synthesize_adaptive_supervisor,
    compute_baseline,
    compute_efficiency_at_frequency,
    plot_frequency_efficiency,
)

# ---------- 全局绘图风格 ----------
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
rcParams['font.size'] = 11
rcParams['axes.labelsize'] = 12
rcParams['axes.titlesize'] = 13
rcParams['xtick.labelsize'] = 10
rcParams['ytick.labelsize'] = 10
rcParams['legend.fontsize'] = 10
rcParams['figure.dpi'] = 150
rcParams['savefig.dpi'] = 300
rcParams['savefig.bbox'] = 'tight'

# 输出目录
OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "results", "figures"
)
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# Fig. A: 耗散效率对比柱状图
# ============================================================
def plot_efficiency_comparison(eta_aodv, eta_isac_no_ctrl, eta_isac_sup,
                                output_path=None):
    """
    绘制三种配置下的耗散效率对比柱状图。

    参数:
        eta_aodv: AODV-MANET 的平均耗散效率
        eta_isac_no_ctrl: ISAC-MANET（无控制）的平均耗散效率
        eta_isac_sup: ISAC-MANET（有 supervisor）的平均耗散效率
        output_path: 输出路径
    """
    if output_path is None:
        output_path = os.path.join(OUTPUT_DIR, "fig_A_efficiency_comparison.png")

    labels = ["AODV-MANET", "ISAC-MANET\n(no control)", "ISAC-MANET\n(with supervisor)"]
    values = [eta_aodv, eta_isac_no_ctrl, eta_isac_sup]
    colors = ["#6baed6", "#74c476", "#fd8d3c"]

    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar(labels, values, color=colors, edgecolor="black", linewidth=0.8)

    # 在柱顶标注数值
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + max(values) * 0.02,
                f"{val:.4f}",
                ha="center", va="bottom", fontsize=10)

    # 标注提升倍数
    ax.annotate(f"×{eta_isac_sup / eta_aodv:.2f}",
                xy=(2, eta_isac_sup),
                xytext=(1.5, eta_isac_sup * 1.15),
                ha="center", fontsize=11, color="red",
                arrowprops=dict(arrowstyle="->", color="red", lw=1.2))

    ax.set_ylabel("Average dissipativity efficiency $\\eta$")
    ax.set_title("Dissipativity Efficiency Comparison")
    ax.set_ylim(0, max(values) * 1.3)
    ax.grid(axis="y", linestyle="--", alpha=0.4)

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"[Fig. A] 已保存: {output_path}")


# ============================================================
# Fig. B: 频率-效率曲线
# ============================================================
def plot_frequency_efficiency_curve(v_data, w_data, f_star,
                                     f_range=None, num_points=200,
                                     output_path=None):
    if output_path is None:
        output_path = os.path.join(OUTPUT_DIR, "fig_B_frequency_efficiency.png")

    f_values, eta_values = plot_frequency_efficiency(
        v_data, w_data, f_range=f_range, num_points=num_points
    )

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(f_values, eta_values, color="#3182bd", linewidth=2, label="$\\eta(f)$")

    # 标注起点 f0 = 0.1
    F0 = 0.1
    eta_0 = compute_efficiency_at_frequency(F0, v_data, w_data)
    ax.plot(F0, eta_0, "bo", markersize=6)
    ax.text(F0 + 0.03, eta_0,
            f"$f_0 = {F0}$\n$\\eta(f_0) = {eta_0:.4f}$",
            fontsize=9, color="blue",
            ha="left", va="center")

    # 标注 f*
    eta_star = compute_efficiency_at_frequency(f_star, v_data, w_data)
    ax.axvline(x=f_star, color="red", linestyle="--", linewidth=1.2,
               label=f"$f^* = {f_star:.3f}$")
    ax.plot(f_star, eta_star, "ro", markersize=6)
    ax.annotate(f"$\\eta(f^*) = {eta_star:.4f}$",
                xy=(f_star, eta_star),
                xytext=(f_star * 1.52, eta_star * 0.99),
                fontsize=10, color="red",
                arrowprops=dict(arrowstyle="->", color="red", lw=1))

    ax.set_xlabel("Sensing frequency $f$")
    ax.set_ylabel("Dissipativity efficiency $\\eta(f)$")
    ax.set_title("Frequency-Efficiency Curve")
    ax.legend(loc="lower right")
    ax.grid(True, linestyle="--", alpha=0.4)

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"[Fig. B] 已保存: {output_path}")


# ============================================================
# Fig. C: 三阶段耗散效率对比
# ============================================================
def plot_phase_efficiency(trans_aodv, trans_isac,
                           output_path=None):
    """
    绘制 AODV-MANET 和 ISAC-MANET 在三个阶段的耗散效率对比。

    参数:
        trans_aodv, trans_isac: 转移关系字典
        output_path: 输出路径
    """
    if output_path is None:
        output_path = os.path.join(OUTPUT_DIR, "fig_C_phase_efficiency.png")

    stats_aodv = aggregate_by_phase(trans_aodv, isac=False)
    stats_isac = aggregate_by_phase(trans_isac, isac=True)

    phases = ["discovery", "maintenance", "recovery"]
    phase_labels = ["Route\nDiscovery", "Route\nMaintenance", "Route\nRecovery"]

    def get_avg_eta(stats, phase):
        if phase not in stats:
            return 0.0
        eff_list = stats[phase]["efficiency_list"]
        if not eff_list:
            return 0.0
        return sum(eff_list) / len(eff_list)

    eta_aodv = [get_avg_eta(stats_aodv, p) for p in phases]
    eta_isac = [get_avg_eta(stats_isac, p) for p in phases]

    x = np.arange(len(phases))
    width = 0.35

    fig, ax = plt.subplots(figsize=(7, 4))
    bars1 = ax.bar(x - width / 2, eta_aodv, width,
                   label="AODV-MANET", color="#6baed6",
                   edgecolor="black", linewidth=0.8)
    bars2 = ax.bar(x + width / 2, eta_isac, width,
                   label="ISAC-MANET", color="#fd8d3c",
                   edgecolor="black", linewidth=0.8)

    # 在柱顶标注数值
    for bars in [bars1, bars2]:
        for bar in bars:
            h = bar.get_height()
            if h > 0:
                ax.text(bar.get_x() + bar.get_width() / 2,
                        h + 0.0005,
                        f"{h:.4f}",
                        ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x)
    ax.set_xticklabels(phase_labels)
    ax.set_ylabel("Average dissipativity efficiency $\\eta$")
    ax.set_title("Phase-wise Dissipativity Efficiency Comparison")
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.4)

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"[Fig. C] 已保存: {output_path}")


# ============================================================
# Fig. D: 状态空间对比
# ============================================================
def plot_state_space_comparison(n_states_aodv, n_trans_aodv,
                                 n_states_isac, n_trans_isac,
                                 output_path=None):
    """
    绘制 AODV-MANET 和 ISAC-MANET 的状态空间对比。

    参数:
        n_states_aodv, n_trans_aodv: AODV 的可达状态数和转移数
        n_states_isac, n_trans_isac: ISAC 的可达状态数和转移数
        output_path: 输出路径
    """
    if output_path is None:
        output_path = os.path.join(OUTPUT_DIR, "fig_D_state_space.png")

    categories = ["Reachable States", "Transitions"]
    aodv_values = [n_states_aodv, n_trans_aodv]
    isac_values = [n_states_isac, n_trans_isac]

    x = np.arange(len(categories))
    width = 0.35

    fig, ax = plt.subplots(figsize=(6, 4))
    bars1 = ax.bar(x - width / 2, aodv_values, width,
                   label="AODV-MANET", color="#6baed6",
                   edgecolor="black", linewidth=0.8)
    bars2 = ax.bar(x + width / 2, isac_values, width,
                   label="ISAC-MANET", color="#fd8d3c",
                   edgecolor="black", linewidth=0.8)

    # 在柱顶标注数值
    for bars in [bars1, bars2]:
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2,
                    h + max(isac_values) * 0.02,
                    f"{int(h)}",
                    ha="center", va="bottom", fontsize=9)

    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.set_ylabel("Count")
    ax.set_title("State Space Comparison")
    ax.set_yscale("log")  # 用对数坐标，因为数量级差异大
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.4)

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"[Fig. D] 已保存: {output_path}")


# ============================================================
# 主流程
# ============================================================
if __name__ == "__main__":
    print(">>> 开始生成论文用图...")
    total_start = time.time()

    # ---------- 可达性遍历 ----------
    print("\n[1/5] 可达性遍历...")
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)

    print(f"AODV: {len(visited_aodv)} states, {len(trans_aodv)} transitions")
    print(f"ISAC: {len(visited_isac)} states, {len(trans_isac)} transitions")

    # ---------- 计算基线 ----------
    print("\n[2/5] 计算基线...")
    v_aodv, w_aodv = compute_baseline(trans_aodv, isac=False)
    v_isac, w_isac = compute_baseline(trans_isac, isac=True)

    eta_aodv = v_aodv / w_aodv if w_aodv > 1e-9 else 0.0
    eta_isac_no_ctrl = v_isac / w_isac if w_isac > 1e-9 else 0.0

    print(f"AODV baseline η = {eta_aodv:.6f}")
    print(f"ISAC (no control) η = {eta_isac_no_ctrl:.6f}")

    # ---------- 自适应监督控制 ----------
    print("\n[3/5] 自适应监督控制...")
    result_isac = synthesize_adaptive_supervisor(
        trans_isac, isac=True, t_wait=10.0, verbose=False
    )
    f_star = result_isac["f_optimal"]
    eta_isac_sup = compute_efficiency_at_frequency(
        f_star, result_isac["v_data"], result_isac["w_data"]
    )
    print(f"ISAC (supervisor) η = {eta_isac_sup:.6f}")
    print(f"Optimal f* = {f_star:.4f}")

    # ---------- Fig. A ----------
    print("\n[4/5] 生成 Fig. A...")
    plot_efficiency_comparison(eta_aodv, eta_isac_no_ctrl, eta_isac_sup)

    # ---------- Fig. B ----------
    print("[4/5] 生成 Fig. B...")
    plot_frequency_efficiency_curve(
        result_isac["v_data"], result_isac["w_data"], f_star
    )

    # ---------- Fig. C ----------
    print("[4/5] 生成 Fig. C...")
    plot_phase_efficiency(trans_aodv, trans_isac)

    # ---------- Fig. D ----------
    print("[4/5] 生成 Fig. D...")
    plot_state_space_comparison(
        len(visited_aodv), len(trans_aodv),
        len(visited_isac), len(trans_isac)
    )

    # ---------- 完成 ----------
    total_end = time.time()
    print(f"\n[5/5] 完成，总耗时 {total_end - total_start:.2f} 秒")
    print(f"所有图已保存到: {OUTPUT_DIR}")