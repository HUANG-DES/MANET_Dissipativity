"""
耗散不等式验证：检查所有可达转移是否满足 ω(e,q) ≥ V(q') − V(q)。
"""

from model.state import State
from model.events import Event
from model.transition import delta_global
from model.storage import V
from model.supply import omega
from analysis.reachability import reachable_states


# 浮点比较容差
EPS = 1e-6


def verify_transition(current: tuple, node_idx: int, event: Event,
                       next_state: tuple, isac: bool = True,
                       t_wait: float = 10.0):
    """
    验证单个转移的耗散不等式 ω(e,q) ≥ V(q') − V(q)。

    返回:
        (是否满足, ω 值, ΔV 值, 差值 ω − ΔV)
    """
    q = current[node_idx]
    q_next = next_state[node_idx]

    dv = V(q_next, t_wait) - V(q, t_wait)
    w = omega(event, q, isac=isac)

    diff = w - dv
    satisfied = diff >= -EPS

    return satisfied, w, dv, diff


def verify_all_transitions(visited, transitions, isac: bool = True,
                            t_wait: float = 10.0):
    """
    验证所有可达转移的耗散不等式。

    返回:
        results: 列表，每项为 (current, node_idx, event, next_state,
                              satisfied, w, dv, diff)
        summary: 统计信息字典
    """
    results = []
    satisfied_count = 0
    violated_count = 0
    zero_margin_count = 0
    violations = []
    zero_margin_transitions = []

    for (current, node_idx, event), next_state in transitions.items():
        satisfied, w, dv, diff = verify_transition(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )
        results.append((current, node_idx, event, next_state,
                        satisfied, w, dv, diff))

        if satisfied:
            satisfied_count += 1
            if abs(diff) < EPS:
                zero_margin_count += 1
                zero_margin_transitions.append(
                    (current, node_idx, event, next_state, w, dv)
                )
        else:
            violated_count += 1
            violations.append((current, node_idx, event, next_state,
                               w, dv, diff))

    summary = {
        "total": len(transitions),
        "satisfied": satisfied_count,
        "violated": violated_count,
        "zero_margin": zero_margin_count,
        "violations": violations,
        "zero_margin_transitions": zero_margin_transitions,
    }

    return results, summary


def print_summary(summary, label: str = ""):
    """
    打印耗散性验证结果摘要。
    """
    print(f"=== {label} ===")
    print(f"总转移数: {summary['total']}")
    print(f"满足耗散不等式: {summary['satisfied']}")
    print(f"违反耗散不等式: {summary['violated']}")
    print(f"结构性零裕度转移: {summary['zero_margin']}")

    if summary["violated"] > 0:
        print("\n--- 违反耗散不等式的转移（前 10 条）---")
        for i, (current, node_idx, event, next_state, w, dv, diff) in \
                enumerate(summary["violations"][:10]):
            print(f"  [{i+1}] {tuple(s.name for s in current)} "
                  f"--(node{node_idx}, {event.name})--> "
                  f"{tuple(s.name for s in next_state)}")
            print(f"      ω = {w:.4f}, ΔV = {dv:.4f}, ω − ΔV = {diff:.4f}")
    else:
        print("所有转移均满足耗散不等式。")

    if summary["zero_margin"] > 0:
        print(f"\n--- 结构性零裕度转移（前 5 条）---")
        for i, (current, node_idx, event, next_state, w, dv) in \
                enumerate(summary["zero_margin_transitions"][:5]):
            print(f"  [{i+1}] {tuple(s.name for s in current)} "
                  f"--(node{node_idx}, {event.name})--> "
                  f"{tuple(s.name for s in next_state)}")
            print(f"      ω = {w:.4f}, ΔV = {dv:.4f}")


def dissipativity_margin(transitions, isac: bool = True,
                          t_wait: float = 10.0, strict: bool = True):
    """
    计算耗散裕度 μ。

    参数:
        strict: True 表示排除结构性零裕度转移（|ω − ΔV| < EPS），
                只统计严格正裕度的转移。

    返回:
        (μ, argmin)
    """
    min_diff = float("inf")
    argmin = None

    for (current, node_idx, event), next_state in transitions.items():
        _, w, dv, diff = verify_transition(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )
        if strict and abs(diff) < EPS:
            continue
        if diff < min_diff:
            min_diff = diff
            argmin = (current, node_idx, event, next_state, w, dv)

    return min_diff, argmin


def compare_aodv_isac(visited_aodv, trans_aodv,
                       visited_isac, trans_isac,
                       t_wait: float = 10.0):
    """
    对比 AODV-MANET 和 ISAC-MANET 的耗散性验证结果。
    """
    print("\n" + "=" * 60)
    print("AODV-MANET vs ISAC-MANET 耗散性对比")
    print("=" * 60)

    _, summary_aodv = verify_all_transitions(visited_aodv, trans_aodv,
                                              isac=False, t_wait=t_wait)
    _, summary_isac = verify_all_transitions(visited_isac, trans_isac,
                                              isac=True, t_wait=t_wait)

    print_summary(summary_aodv, "AODV-MANET")
    print()
    print_summary(summary_isac, "ISAC-MANET")

    mu_aodv, argmin_aodv = dissipativity_margin(trans_aodv, isac=False,
                                                 t_wait=t_wait, strict=True)
    mu_isac, argmin_isac = dissipativity_margin(trans_isac, isac=True,
                                                 t_wait=t_wait, strict=True)

    print("\n--- 耗散裕度 μ（排除结构性零裕度转移）---")
    print(f"AODV-MANET: μ = {mu_aodv:.4f}")
    print(f"ISAC-MANET: μ = {mu_isac:.4f}")

    if mu_aodv > 0:
        print("  AODV-MANET 存在正耗散裕度，Theorem 2 的条件满足。")
    else:
        print("  AODV-MANET 耗散裕度非正，需要调整参数。")

    if mu_isac > 0:
        print("  ISAC-MANET 存在正耗散裕度，Theorem 2 的条件满足。")
    else:
        print("  ISAC-MANET 耗散裕度非正，需要调整参数。")


if __name__ == "__main__":
    print(">>> 开始可达性遍历...")
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)

    print(f"AODV 可达状态: {len(visited_aodv)}, 转移数: {len(trans_aodv)}")
    print(f"ISAC 可达状态: {len(visited_isac)}, 转移数: {len(trans_isac)}")

    compare_aodv_isac(visited_aodv, trans_aodv, visited_isac, trans_isac)