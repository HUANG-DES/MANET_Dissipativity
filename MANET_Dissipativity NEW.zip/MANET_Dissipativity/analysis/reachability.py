"""
可达状态遍历：从初始状态 BFS 出发，筛出实际可达的全局状态。

约束来源：参考论文《K-Step Mutual Knowledge Opacity in DESs for MANETs》
中的五类约束（实际通信路由、协议逻辑、状态转移、全局不可达、非法状态）。
"""

from collections import deque, Counter

from model.state import State, ISAC_ORDER, AODV_ORDER
from model.events import Event, AODV_EVENTS, ISAC_EVENTS
from model.transition import delta_global


# ---------- 七节点拓扑 ----------
# 节点索引：0=A, 1=B, 2=C, 3=D, 4=E, 5=F, 6=G
ADJACENCY = {
    0: {1, 2},        # A 连接 B, C
    1: {0, 2, 3},     # B 连接 A, C, D
    2: {0, 1},        # C 连接 A, B
    3: {1, 4, 5, 6},  # D 连接 B, E, F, G
    4: {3, 5},        # E 连接 D, F
    5: {3, 4, 6},     # F 连接 D, E, G
    6: {3, 5},        # G 连接 D, F
}


def is_connected(nodes: set, adjacency: dict) -> bool:
    """
    检查一组节点是否连通。

    参数:
        nodes: 节点索引集合
        adjacency: 邻接关系

    返回:
        True 表示连通（空集或单元素集也视为连通）
    """
    if len(nodes) <= 1:
        return True
    nodes = set(nodes)
    start = next(iter(nodes))
    visited = {start}
    queue = [start]
    while queue:
        current = queue.pop()
        for neighbor in adjacency.get(current, set()):
            if neighbor in nodes and neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited == nodes


def allow_transition(current: tuple, node_idx: int, event: Event, isac: bool) -> bool:
    """
    判断某个转移是否允许发生（协议逻辑 + 全局约束）。

    约束：
    1. 同时处于非 I 状态的节点数不超过 4。
    2. W 节点集合必须连通。
    3. A 节点集合必须连通。
    4. 非路由节点（C, E, G）不能发起 BR/FR/RR/EW/AC。
    """
    # 约束 1：同时处于非 I 状态的节点数不超过 4
    non_idle = {i for i, s in enumerate(current) if s != State.I}
    if len(non_idle) > 4:
        return False

    # 约束 2：W 节点必须连通
    wait_nodes = {i for i, s in enumerate(current) if s == State.W}
    if not is_connected(wait_nodes, ADJACENCY):
        return False

    # 约束 3：A 节点必须连通
    active_nodes = {i for i, s in enumerate(current) if s == State.A}
    if not is_connected(active_nodes, ADJACENCY):
        return False

    # 约束 4：非路由节点不能发起路由相关事件
    ROUTE_NODES = {0, 1, 3, 5}  # A, B, D, F
    if node_idx not in ROUTE_NODES:
        if event in (Event.BR, Event.FR, Event.RR, Event.EW, Event.AC):
            return False

    return True


def reachable_states(num_nodes: int = 7, isac: bool = True, max_states: int = 500000):
    """
    从初始状态出发，BFS 遍历所有可达的全局状态（带约束）。

    参数:
        num_nodes: 节点数
        isac: True 表示 ISAC-MANET，False 表示 AODV-MANET
        max_states: 状态数上限，防止状态爆炸

    返回:
        (可达状态集合, 转移关系字典)
    """
    events = ISAC_EVENTS if isac else AODV_EVENTS
    initial = (State.I,) * num_nodes

    visited = {initial}
    queue = deque([initial])
    transitions = {}

    while queue:
        current = queue.popleft()

        for node_idx in range(num_nodes):
            for event in events:
                if not allow_transition(current, node_idx, event, isac):
                    continue

                next_state = delta_global(current, node_idx, event)
                if next_state is None:
                    continue

                transitions[(current, node_idx, event)] = next_state

                if next_state not in visited:
                    visited.add(next_state)
                    queue.append(next_state)

                    if len(visited) >= max_states:
                        print(f"[警告] 可达状态数达到上限 {max_states}，提前终止。")
                        return visited, transitions

    return visited, transitions


def summarize_reachability(visited, isac: bool = True):
    """
    统计可达状态的基本信息。
    """
    print(f"可达状态总数: {len(visited)}")

    counter = Counter()
    for g in visited:
        for s in g:
            counter[s.name] += 1

    print("各状态出现次数（按节点-状态计数）:")
    order = ISAC_ORDER if isac else AODV_ORDER
    for s in order:
        print(f"  {s.name}: {counter[s.name]}")


if __name__ == "__main__":
    print("=== 七节点 AODV-MANET 可达性分析 ===")
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    summarize_reachability(visited_aodv, isac=False)
    print(f"转移关系数: {len(trans_aodv)}")

    print("\n=== 七节点 ISAC-MANET 可达性分析 ===")
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)
    summarize_reachability(visited_isac, isac=True)
    print(f"转移关系数: {len(trans_isac)}")