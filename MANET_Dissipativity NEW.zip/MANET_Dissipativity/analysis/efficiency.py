"""
耗散效率计算：统计不同阶段的耗散量 D 和耗散效率 η。

定义：
    耗散量 D = ω − ΔV（当 ΔV > 0）
    耗散效率 η = ΔV / ω（当 ω > 0）
"""

from collections import defaultdict

from model.state import State
from model.events import Event
from model.storage import V
from model.supply import omega
from analysis.reachability import reachable_states


EPS = 1e-9


# ---------- 阶段划分 ----------
# 路由发现阶段涉及的事件
DISCOVERY_EVENTS = {
    Event.BR, Event.FR, Event.RQ, Event.RR, Event.TO, Event.SO,
}

# 路由保持阶段涉及的事件
MAINTENANCE_EVENTS = {
    Event.SS, Event.SC, Event.CS, Event.EW, Event.AC, Event.RT,
}

# 路由恢复阶段涉及的事件
RECOVERY_EVENTS = {
    Event.LD, Event.RE,
}


def classify_event(event: Event) -> str:
    """
    判断事件属于哪个阶段。
    """
    if event in DISCOVERY_EVENTS:
        return "discovery"
    elif event in MAINTENANCE_EVENTS:
        return "maintenance"
    elif event in RECOVERY_EVENTS:
        return "recovery"
    else:
        return "unknown"


def compute_efficiency(current, node_idx, event, next_state,
                        isac=True, t_wait=10.0):
    q = current[node_idx]
    q_next = next_state[node_idx]

    dv = V(q_next, t_wait) - V(q, t_wait)
    w = omega(event, q, isac=isac)

    # 耗散量只在 ΔV > 0 时有意义
    if dv > EPS and w > EPS:
        dissipation = w - dv
        efficiency = dv / w
    else:
        dissipation = None
        efficiency = None

    return w, dv, dissipation, efficiency


def aggregate_by_phase(transitions, isac: bool = True, t_wait: float = 10.0):
    """
    按阶段汇总耗散量和耗散效率。

    返回:
        phase_stats: {phase: {"total_w": ..., "total_dv": ..., "count": ...,
                              "efficiency_list": [...], "dissipation_list": [...]}}
    """
    phase_stats = defaultdict(lambda: {
        "total_w": 0.0,
        "total_dv": 0.0,
        "count": 0,
        "efficiency_list": [],
        "dissipation_list": [],
    })

    for (current, node_idx, event), next_state in transitions.items():
        phase = classify_event(event)
        w, dv, dissipation, efficiency = compute_efficiency(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )

        stats = phase_stats[phase]
        stats["total_w"] += w
        stats["total_dv"] += dv
        stats["count"] += 1

        if efficiency is not None:
            stats["efficiency_list"].append(efficiency)
        if dissipation is not None:
            stats["dissipation_list"].append(dissipation)

    return phase_stats


def print_phase_stats(phase_stats, label: str = ""):
    """
    打印分阶段统计结果。
    """
    print(f"\n=== {label} 分阶段耗散性统计 ===")
    print(f"{'阶段':<14}{'转移数':<10}{'总供给率':<14}{'总ΔV':<12}"
          f"{'平均η':<10}{'平均耗散量':<12}")

    for phase in ["discovery", "maintenance", "recovery"]:
        if phase not in phase_stats:
            continue
        stats = phase_stats[phase]

        avg_eta = 0.0
        if stats["efficiency_list"]:
            avg_eta = sum(stats["efficiency_list"]) / len(stats["efficiency_list"])

        avg_dissipation = 0.0
        if stats["dissipation_list"]:
            avg_dissipation = (sum(stats["dissipation_list"]) /
                               len(stats["dissipation_list"]))

        print(f"{phase:<14}{stats['count']:<10}"
              f"{stats['total_w']:<14.2f}"
              f"{stats['total_dv']:<12.4f}"
              f"{avg_eta:<10.4f}"
              f"{avg_dissipation:<12.4f}")


def compare_efficiency_aodv_isac(visited_aodv, trans_aodv,
                                  visited_isac, trans_isac,
                                  t_wait: float = 10.0):
    """
    对比 AODV-MANET 和 ISAC-MANET 的三阶段耗散效率。
    """
    print("\n" + "=" * 70)
    print("AODV-MANET vs ISAC-MANET 三阶段耗散效率对比")
    print("=" * 70)

    stats_aodv = aggregate_by_phase(trans_aodv, isac=False, t_wait=t_wait)
    stats_isac = aggregate_by_phase(trans_isac, isac=True, t_wait=t_wait)

    print_phase_stats(stats_aodv, "AODV-MANET")
    print_phase_stats(stats_isac, "ISAC-MANET")

    # 计算全局平均效率
    print("\n--- 全局平均耗散效率 ---")
    for label, stats in [("AODV-MANET", stats_aodv),
                          ("ISAC-MANET", stats_isac)]:
        all_eta = []
        for phase in stats.values():
            all_eta.extend(phase["efficiency_list"])
        if all_eta:
            avg = sum(all_eta) / len(all_eta)
            print(f"{label}: 平均 η = {avg:.4f}（基于 {len(all_eta)} 条转移）")


def efficiency_by_event_type(transitions, isac: bool = True,
                              t_wait: float = 10.0):
    """
    按事件类型汇总耗散效率。
    """
    event_stats = defaultdict(lambda: {
        "count": 0,
        "total_w": 0.0,
        "total_dv": 0.0,
        "efficiency_list": [],
    })

    for (current, node_idx, event), next_state in transitions.items():
        w, dv, _, efficiency = compute_efficiency(
            current, node_idx, event, next_state,
            isac=isac, t_wait=t_wait
        )
        stats = event_stats[event.name]
        stats["count"] += 1
        stats["total_w"] += w
        stats["total_dv"] += dv
        if efficiency is not None:
            stats["efficiency_list"].append(efficiency)

    return event_stats


def print_event_stats(event_stats, label: str = ""):
    """
    打印按事件类型的统计结果。
    """
    print(f"\n=== {label} 按事件类型统计 ===")
    print(f"{'事件':<10}{'转移数':<10}{'总ω':<12}{'总ΔV':<12}{'平均η':<10}")

    for event_name in sorted(event_stats.keys()):
        stats = event_stats[event_name]
        avg_eta = 0.0
        if stats["efficiency_list"]:
            avg_eta = sum(stats["efficiency_list"]) / len(stats["efficiency_list"])
        print(f"{event_name:<10}{stats['count']:<10}"
              f"{stats['total_w']:<12.2f}"
              f"{stats['total_dv']:<12.4f}"
              f"{avg_eta:<10.4f}")


if __name__ == "__main__":
    print(">>> 开始可达性遍历...")
    visited_aodv, trans_aodv = reachable_states(num_nodes=7, isac=False)
    visited_isac, trans_isac = reachable_states(num_nodes=7, isac=True)

    print(f"AODV 可达状态: {len(visited_aodv)}, 转移数: {len(trans_aodv)}")
    print(f"ISAC 可达状态: {len(visited_isac)}, 转移数: {len(trans_isac)}")

    compare_efficiency_aodv_isac(
        visited_aodv, trans_aodv,
        visited_isac, trans_isac
    )

    # 按事件类型细分（可选）
    print("\n" + "=" * 70)
    print("按事件类型细分")
    print("=" * 70)
    event_stats_aodv = efficiency_by_event_type(trans_aodv, isac=False)
    event_stats_isac = efficiency_by_event_type(trans_isac, isac=True)
    print_event_stats(event_stats_aodv, "AODV-MANET")
    print_event_stats(event_stats_isac, "ISAC-MANET")